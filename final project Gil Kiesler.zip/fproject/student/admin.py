from django.contrib import admin
from student.models import Studentdetails, Coursedetails

# Register your models here.

admin.site.register(Studentdetails)
admin.site.register(Coursedetails)